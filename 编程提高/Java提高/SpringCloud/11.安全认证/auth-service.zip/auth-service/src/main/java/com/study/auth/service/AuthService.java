package com.study.auth.service;

import com.study.auth.po.User;
import com.study.auth.query.AuthQuery;

public interface AuthService {

	User auth(AuthQuery query);
	
}
