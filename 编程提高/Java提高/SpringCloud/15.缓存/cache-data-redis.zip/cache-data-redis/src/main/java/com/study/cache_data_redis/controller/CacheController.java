package com.study.cache_data_redis.controller;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.cache_data_redis.po.Person;
import com.study.cache_data_redis.repository.PersonRepository;

@RestController
public class CacheController {

	@Autowired
	private StringRedisTemplate stringRedisTemplate;

	@Autowired
	PersonRepository repo;

    @GetMapping("/testRedisTemplate")
    public String testRedisTemplate() {
        stringRedisTemplate.opsForValue().set("url", "www.learn1024.com", 1, TimeUnit.HOURS);
        String value = stringRedisTemplate.opsForValue().get("url");
        System.out.println(value);
        stringRedisTemplate.delete("url");
        boolean exists = stringRedisTemplate.hasKey("url");
        System.out.println(exists);
        RedisConnection connection = stringRedisTemplate.getConnectionFactory().getConnection();
        connection.set("url".getBytes(), "www.learn1024.com".getBytes());
        System.out.println(new String(connection.get("url".getBytes())));
        return "success";
    }

	@GetMapping("/testReop")
	public void testReop() {
		Person person = new Person();
		person.setFirstname("John");
		person.setLastname("alpha");
        System.out.println("Before save person id = " + person.getId());
		repo.save(person);
        System.out.println("After save person id = " + person.getId());
		Optional<Person> personObj = repo.findById(person.getId());
		System.err.println(personObj.get().getFirstname());
		System.err.println(repo.count());
		repo.delete(person);
	}

    @GetMapping("/testReopSave")
    public void testReopSave() {
        Person person = new Person();
        person.setFirstname("John");
        person.setLastname("alpha");
        repo.save(person);
    }
}
