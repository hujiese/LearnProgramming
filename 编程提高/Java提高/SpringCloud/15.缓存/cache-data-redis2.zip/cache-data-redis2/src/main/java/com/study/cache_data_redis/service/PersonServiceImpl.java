package com.study.cache_data_redis.service;

import com.study.cache_data_redis.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.study.cache_data_redis.po.Person;

import java.util.Optional;

@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    private PersonRepository repo;

	@Cacheable(value = "get", keyGenerator = "keyGenerator")
	public Person get(String id) {
        Optional<Person> personObj = repo.findById(id);
        System.out.println("PersonService get function invoke...");
	    return personObj.get();
	}
	
}
