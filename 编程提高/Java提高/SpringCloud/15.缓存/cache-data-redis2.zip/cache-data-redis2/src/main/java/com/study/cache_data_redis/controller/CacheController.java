package com.study.cache_data_redis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.study.cache_data_redis.po.Person;
import com.study.cache_data_redis.repository.PersonRepository;
import com.study.cache_data_redis.service.CacheService;
import com.study.cache_data_redis.service.Closure;
import com.study.cache_data_redis.service.PersonService;

@RestController
public class CacheController {

	@Autowired
	PersonRepository repo;

	@Autowired
	private PersonService personService;

	@Autowired
	private CacheService cacheService;
	
	@GetMapping("/save")
	public String save() {
		Person person = new Person();
		person.setFirstname("John");
		person.setLastname("alpha");
		repo.save(person);
		return person.toString();
	}

	@GetMapping("/get/{id}")
	public String get(@PathVariable String id) {
		return personService.get(id).toString();
	}

	@GetMapping("/getCallback/{id}")
	public String getCallback(@PathVariable String id) {
		String cacheKey = id;
		return cacheService.getCache(cacheKey, new Closure<String, String>() {
			@Override
			public String execute(String id) {
				// 执行你的业务逻辑
				return id+"hello";
			}
		});
	}
}
