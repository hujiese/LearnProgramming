package com.study.cache_data_redis.service;

import com.study.cache_data_redis.po.Person;

public interface PersonService {
	public Person get(String id);
}
