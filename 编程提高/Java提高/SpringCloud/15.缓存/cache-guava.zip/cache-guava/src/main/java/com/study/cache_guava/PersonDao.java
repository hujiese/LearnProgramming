package com.study.cache_guava;

public class PersonDao {

	Person findById(String id) {
		System.err.println("query id:" + id);
		Person p = new Person();
		p.setName("John");
		return p;
	}
}
