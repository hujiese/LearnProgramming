package com.study.zuul_demo.config;

import com.study.zuul_demo.filter.DownGradeFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {

	@Bean
	public DownGradeFilter downGradeFilter() {
		return new DownGradeFilter();
	}
}
