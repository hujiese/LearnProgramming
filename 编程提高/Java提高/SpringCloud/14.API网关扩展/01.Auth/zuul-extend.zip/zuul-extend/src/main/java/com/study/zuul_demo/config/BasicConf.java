package com.study.zuul_demo.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import com.google.common.util.concurrent.RateLimiter;

import lombok.Data;

@Data
@Configuration
public class BasicConf {
	
	// API接口白名单，多个用逗号分隔
	@Value("${apiWhiteStr:/zuul-extend-user-service/user/login}")
	private String apiWhiteStr;
}
