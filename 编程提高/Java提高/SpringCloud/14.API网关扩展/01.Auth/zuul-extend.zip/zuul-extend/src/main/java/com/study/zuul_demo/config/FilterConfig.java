package com.study.zuul_demo.config;

import com.study.zuul_demo.filter.AuthFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FilterConfig {

	@Bean
	public AuthFilter authFilter() {
		return new AuthFilter();
	}

}
