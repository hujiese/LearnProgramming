package com.study.auth.service;

import org.springframework.stereotype.Service;

import com.study.auth.po.User;
import com.study.auth.query.AuthQuery;

@Service
public class AuthServiceImpl implements AuthService {

	@Override
	public User auth(AuthQuery query) {
		return new User(1L);
	}

}
