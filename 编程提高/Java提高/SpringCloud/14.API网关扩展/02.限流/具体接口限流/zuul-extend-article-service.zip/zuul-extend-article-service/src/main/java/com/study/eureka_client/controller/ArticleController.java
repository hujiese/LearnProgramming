package com.study.eureka_client.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.eureka_client.apilimit.ApiRateLimit;
import com.study.eureka_client.feign.UserRemoteClient;

@RestController
public class ArticleController {
	
	@Autowired
	private UserRemoteClient userRemoteClient;
	
	@ApiRateLimit(confKey = "open.api.callHello")
	@GetMapping("/article/callHello") 	
	public String callHello() {
	    return userRemoteClient.hello();
	}
	
}
