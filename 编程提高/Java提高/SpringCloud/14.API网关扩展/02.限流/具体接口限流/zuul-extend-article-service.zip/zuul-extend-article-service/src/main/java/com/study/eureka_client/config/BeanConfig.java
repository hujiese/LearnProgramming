package com.study.eureka_client.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.study.eureka_client.apilimit.ApiLimitAspect;

@Configuration
public class BeanConfig {
	
	@Bean
	public ApiLimitAspect apiLimitAspect() {
		return new ApiLimitAspect();
	}
}
