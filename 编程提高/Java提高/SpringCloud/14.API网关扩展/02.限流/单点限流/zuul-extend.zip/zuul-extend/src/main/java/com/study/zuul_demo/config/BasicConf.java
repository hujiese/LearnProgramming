package com.study.zuul_demo.config;

import com.google.common.util.concurrent.RateLimiter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.model.ConfigChangeEvent;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfigChangeListener;
import com.study.zuul_demo.filter.LimitFilter;

import lombok.Data;

@Data
@Configuration
public class BasicConf {

	@Value("${limitRate:10}")
	private double limitRate;

	@ApolloConfig
	private Config config;

	@ApolloConfigChangeListener
	public void onChange(ConfigChangeEvent changeEvent) {
		if (changeEvent.isChanged("limitRate")) {
			// 更 新 RateLimiter
			System.err.println(config.getDoubleProperty("limitRate", 10.0));
			LimitFilter.rateLimiter = RateLimiter.create(config.getDoubleProperty("limitRate", 10.0));
		}
	}

}
