//package com.test.config;
//
//import org.apache.catalina.core.AprLifecycleListener;
//import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
//import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class AprConfiguration {
//    @Bean
//    public ConfigurableServletWebServerFactory webServerFactory() {
//        TomcatServletWebServerFactory factory = new TomcatServletWebServerFactory();
//        // 开启 apr 模式
//        factory.setProtocol("org.apache.coyote.http11.Http11AprProtocol");
//
//        // 不启用 SSL (我的springboot跑在nginx反向代理之后,之间的调用是http的,不需要SSL)
//        AprLifecycleListener listener = new AprLifecycleListener();
//        String valueOff = "off";
//        listener.setFIPSMode(valueOff);
//        listener.setSSLEngine(valueOff);
//        listener.setUseOpenSSL(false);
//
//        factory.addContextLifecycleListeners(listener);
//        return factory;
//    }
//}